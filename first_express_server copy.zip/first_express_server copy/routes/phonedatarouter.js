const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const phones = require('../models/phone');

const phonedatarouter = express.Router();

phonedatarouter.route('/')
.get((req,res,next) => {
    res.render('index.ejs',{ title: 'Phone Data Entry' });
})
.post((req, res, next) => {

})
.put((req, res, next) => {
})
.delete((req, res, next) => {
});


phonedatarouter.route('/create')
.get((req,res,next) => {
    res.render('datadisplay.ejs', { title: 'Data Usage' });   
})

.post((req, res, next) => {
    phones.create(req.body)
    .then((datataken) => {
        phones.find()
         .then((datafound) => {
                res.render('dataheld.ejs',{'datadisplay' : datafound, title:'All data recieved from user'} );//can use datadisplay
        }, (err) => next(err))
    .catch((err) => next(err));
    }, (err) => next(err))
    .catch((err) => next(err));
})

.put((req, res, next) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /phones/datausage');
})

.delete((req, res, next) => {
    res.statusCode = 403;
    res.end('Delete operation not  supported on /phones/datausage');
    
});


module.exports = phonedatarouter;