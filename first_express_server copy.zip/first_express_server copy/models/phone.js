const mongoose = require('mongoose');
const Schema = mongoose.Schema;

require('mongoose-currency').loadType(mongoose);
var Currency = mongoose.Types.Currency;

var dataphoneScemaful = new Schema({
    name: {
        type: String,
        required: true,
    },
    Education: {
        type: String,
        required: true,
    },
    Shoppingsites: {
        type: String,
        required: true,
    },
    searchingbrowsing: {
        type: String,
        required: true,
    },
    socialmedia: {
        type: String,
        required: true,
    }


}, {
    timestamps: true
});
var phones = mongoose.model('phone', dataphoneScemaful);

module.exports = phones