def update_bookings(accommodation_type):
    f = open("Bookings_2022.txt", "r")
    read_lines = f.readlines()
    f.close()
    strings_list = []
    bookings_list = []
    for line in read_lines:
        line = line.strip()
        strings_list.append(line)
        line = line.split()
        bookings_list.append(int(line[-1]))

    if sum(bookings_list) < 30:
        if accommodation_type == 1:
            line_string = "Deluxe, 2000, "
            booking_count = int(bookings_list[0]) + 1
            line_string = line_string + str(booking_count)
            strings_list[0] = line_string
        if accommodation_type == 2:
            line_string = "Standard, 1600, "
            booking_count = int(bookings_list[1]) + 1
            line_string = line_string + str(booking_count)
            strings_list[1] = line_string
        if accommodation_type == 3:
            line_string = "Camp, 200, "
            booking_count = int(bookings_list[2]) + 1
            line_string = line_string + str(booking_count)
            strings_list[2] = line_string
        return_accommodation_string = ""
        for text in strings_list:
            return_accommodation_string = return_accommodation_string + text + "\n"
        f = open("Bookings_2022.txt", "w")
        f.write(return_accommodation_string)
        f.close()
        return False
    else:
        print("Maximum bookings made!")
        return True


# For all my files i broke the file information down into lists appended the information to the list and
# instead of creating a new function
# for saving i did it in the same function i put the information back into the file in the
# suitable file order and then wrote the information back to the file in this
# in this above example it being the bookings file just updating the number of bookings for each site being booked


def update_extras_family_pass(family_pass):
    f = open("Extras.txt", "r")
    read_lines = f.readlines()
    f.close()
    strings_extras_list = []
    bookings_kc_fp = []
    for text in read_lines:
        text = text.strip()
        strings_extras_list.append(text)
        text = text.split()
        bookings_kc_fp.append(int(text[-1]))

    if family_pass == 'y' or 'Y':
        fp_string = "pool pass, "
        fp_bookings = int(bookings_kc_fp[0]) + 1
        fp_string = fp_string + str(fp_bookings)
        strings_extras_list[0] = fp_string

    return_fp_cc_string = ""
    for text in strings_extras_list:
        return_fp_cc_string = return_fp_cc_string + text + "\n"

    f = open("Extras.txt", "w")
    f.write(return_fp_cc_string)
    f.close()


# Same method as the file above


def update_extras_children_camp(no_of_children):
    f = open("Extras.txt", "r")
    read_lines = f.readlines()
    f.close()
    strings_extras_list = []
    bookings_kc_fp = []
    for text in read_lines:
        text = text.strip()
        strings_extras_list.append(text)
        text = text.split()
        bookings_kc_fp.append(int(text[-1]))
    if no_of_children > 0:
        cc_string = "kids camp, "
        cc_bookings = int(bookings_kc_fp[1]) + no_of_children
        cc_string = cc_string + str(cc_bookings)
        strings_extras_list[1] = cc_string

    return_fp_cc_string = ""
    for text in strings_extras_list:
        return_fp_cc_string = return_fp_cc_string + text + "\n"
    f = open("Extras.txt", "w")
    f.write(return_fp_cc_string)
    f.close()


def menu():
    print("LONG ISLAND HOLIDAYS")
    print("=" * 20)
    try:
        menu_selection = int(input("1. Make a Booking\n2. Review Bookings\n3. Exit\n==>"))
        while menu_selection != 3:
            if menu_selection == 1:
                bookings()

            elif menu_selection == 2:
                review_bookings()
            menu_selection = int(input("1. Make a Booking\n2. Review Bookings\n3. Exit\n==>"))

    except ValueError:
        print("must only enter 1,2,3")


# I put in a while loop but when i did this when i hit 3 to exit it would not finish and would not create the file with
# the customers booking details with the unique name and id wasn't able to find the solution to this


def booking_surname():
    while True:

        surname = str(input("Enter your family name: "))
        if 1 < len(surname) < 14 and surname.isalpha():
            return surname
        else:
            print("invalid surname please enter again")


def booking_phone_number():
    while True:
        try:
            phone_number = int(input("Enter your phone number here: "))
            if len(str(phone_number)) < 12:
                return phone_number
        except ValueError:
            print("invalid phone number please enter again")


def booking_choose_accommodation_type():
    while True:
        try:
            f = open("Bookings_2022.txt", "r")
            read_lines = f.readlines()
            f.close()
            strings_list = []
            bookings_list = []
            for line in read_lines:
                line = line.strip()
                strings_list.append(line)
                line = line.split()
                bookings_list.append(int(line[-1]))
            accommodation_type = int(input(f"1.Deluxe Caravan (€2000.0) {bookings_list[0]} booked\n"
                                           f"2.Standard Caravan (€1600.0) {bookings_list[1]} booked\n"
                                           f"3. Camp Site (€200) {bookings_list[2]} booked\n"
                                           f"4.No Booking\n=>"))
            if accommodation_type == 1:
                maximum_bookings = update_bookings(accommodation_type)
                if maximum_bookings == False:
                    return "Deluxe Caravan"
                else:
                    accommodation_type = 4
            elif accommodation_type == 2:
                maximum_bookings = update_bookings(accommodation_type)
                if maximum_bookings == False:
                    return "Standard Caravan"
                else:
                    accommodation_type = 4

            elif accommodation_type == 3:
                maximum_bookings = update_bookings(accommodation_type)
                if maximum_bookings == False:

                    return "Camp Site"
                else:
                    accommodation_type = 4
            elif accommodation_type == 4:
                return "No Booking"
        except ValueError:
            print("Must only enter numbers 1,2,3 or 4")


def booking_people_in_group():
    while True:
        try:
            people_in_group = int(input("How many people in your group? "))
            if people_in_group > 0:
                return people_in_group
        except ValueError:
            print("Must be a positive integer only please enter again")


def booking_family_pass():
    while True:
        try:
            family_pass = str(input("Do you require a family pass (Y/N)? "))
            if family_pass == 'Y' or family_pass == 'y' or family_pass == 'N' or family_pass == 'n':
                update_extras_family_pass(family_pass)
                return family_pass
        except ValueError:
            print("Input must be y or n nothing else enter again")


def booking_no_of_children():
    while True:
        try:
            no_of_children = int(input("How many kids will join the kids club? "))
            if 0 < no_of_children:
                update_extras_children_camp(no_of_children)
                return no_of_children
        except ValueError:
            print(f" Must be a positive integer and less than people going")


def review_bookings():
    f = open("Bookings_2022.txt", "r")
    f2 = open("Extras.txt", "r")

    read_line = f.readlines()
    read_line_extras = f2.readlines()
    f.close()
    f2.close()
    bookings_list = []
    bookings_list_str = []
    extras_list = []
    extras_list_str = []
    for text in read_line:
        text = text.strip()
        bookings_list_str.append(text)
        text = text.split()
        bookings_list.append(int(text[-1]))
        print(bookings_list)

    for text in read_line_extras:
        text = text.strip()
        extras_list_str.append(text)
        text = text.split()
        extras_list.append(int(text[-1]))

    print("LONG ISLAND HOLIDAYS - Review of Bookings")
    print('=' * 41)
    print(f"Deluxe Caravan:              {bookings_list[0]}")
    print(f"Standard Caravan:            {bookings_list[1]}")
    print(f"Camp:                        {bookings_list[2]}\n")
    print(f"Total no. of Pool Passes:    {extras_list[0]}")
    print(f"No. for Kids Club:           {extras_list[1]}")
    if bookings_list[0] < bookings_list[1] < bookings_list[2]:
        print("Most popular accommodation:  Camp")
    if bookings_list[0] < bookings_list[1] > bookings_list[2]:
        print("Most popular accommodation:  Standard Camp")
    if bookings_list[0] > bookings_list[1] > bookings_list[2]:
        print("Most popular accommodation:  Deluxe Camp")

    deluxe_income = (bookings_list[0]) * 2000

    standard_income = (bookings_list[1]) * 1600

    camp_income = (bookings_list[2]) * 200

    kids_club_income = (bookings_list[0]) * 100

    fam_pass = (bookings_list[1]) * 150

    total_income = deluxe_income + standard_income + camp_income + kids_club_income + fam_pass
    average_cost_booking = int(total_income) // 3
    print(f"Expected Income:             {total_income}")

    print(f"Average per booking:         {average_cost_booking}")
    remaining_sites = 30 - sum(bookings_list)
    print(f"Number of remaining sites:   {remaining_sites}")


def bookings():
    while True:
        surname = booking_surname()
        phone_number = booking_phone_number()
        accommodation_type = booking_choose_accommodation_type()
        people_in_group = booking_people_in_group()
        family_pass = booking_family_pass()
        no_of_children = booking_no_of_children()
        while people_in_group < no_of_children:
            print("More children than adults please go again")
            no_of_children = booking_no_of_children()
        booking_details(surname, accommodation_type, people_in_group, family_pass, no_of_children)
        break


def booking_details(surname, accommodation_type, people_in_group, family_pass, no_of_children):
    cost_at = cost_at_a(accommodation_type)
    total = total_cost(accommodation_type, no_of_children, family_pass)
    f = open("Bookings_2022.txt", "r")
    read_line = f.readlines()
    f.close()
    booking_list = []
    booking_list_str = []
    for text in read_line:
        text = text.strip()
        booking_list_str.append(text)
        text = text.split()
        booking_list.append(int(text[-1]))
    id_num = sum(booking_list)
    print("Booking Details")
    print('-' * 15)
    print(f"\nName:                  {surname}")
    print(f"Booking id:            {id_num}")
    print(f"Accommodation Type:    {accommodation_type}")
    print(f"No of people:          {people_in_group}")
    print(f"Pool pass:             {family_pass}")
    print(f"No. for kids club:     {no_of_children}")
    print(f"Cost Accommodation:    {cost_at}")
    print(f"Total cost:            {total}")
    f = open(f"{surname}_{id_num}.txt", "w")
    f.writelines(f" Booking Details"
                 f"\n ---------------"
                 f"\n Booking id: {id_num}"
                 f"\n Accommodation Type: {accommodation_type}"
                 f"\n No of people: {people_in_group}"
                 f"\n Pool pass: {family_pass}"
                 f"\n No. for kids club: {no_of_children}"
                 f"\n Cost Accommodation: {cost_at}")
    f.close()


def cost_at_a(accommodation_type):
    if accommodation_type == "Deluxe Caravan":
        cost_at = 2000
    elif accommodation_type == "Standard Caravan":
        cost_at = 1600
    else:
        cost_at = 200
    return cost_at


def cost_children_b(no_of_children):
    cost_children = no_of_children * 100
    return cost_children


def cost_family_pass_c(family_pass):
    if family_pass == 'y' or family_pass == 'Y':
        cost_family_pass = 150
        return cost_family_pass
    elif family_pass == 'n' or family_pass == 'N':
        cost_family_pass_none = 0
        return cost_family_pass_none


def total_cost(accommodation_type, no_of_children, family_pass):
    cost_at = cost_at_a(accommodation_type)
    cost_children = cost_children_b(no_of_children)
    total_family_pass = cost_family_pass_c(family_pass)
    total = cost_at + cost_children + total_family_pass
    return total


def main():
    print("sean")
    menu()


main()
