const mongoose = require('mongoose');
const Schema = mongoose.Schema;

require('mongoose-currency').loadType(mongoose);
var Currency = mongoose.Types.Currency;

var dataphoneScemaful = new Schema({
    name: {
        type: String,
        required: true,
    },
    Education: {
        type: Number,
        required: true,
    },
    Shoppingsites: {
        type: Number,
        required: true,
    },
    searchingbrowsing: {
        type: Number,
        required: true,
    },
    socialmedia: {
        type: Number,
        required: true,
    }

}, {
    timestamps: true
});
var phones = mongoose.model('phone', dataphoneScemaful);


module.exports = phones