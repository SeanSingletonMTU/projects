const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const phones = require('../models/phone');

const phonedatarouter = express.Router();

phonedatarouter.route('/')
.get((req,res,next) => {
    res.render('index.ejs',{ title: 'Phone Data Entry' });
})
.post((req, res, next) => {

})
.put((req, res, next) => {
})
.delete((req, res, next) => {
});


phonedatarouter.route('/create')
.get((req,res,next) => {
    res.render('datadisplay.ejs', { title: 'Data Usage' });   
})

.post((req, res, next) => {
    phones.create(req.body)
    .then((datataken) => {
        phones.find()
         .then((datafound) => {
                res.render('dataheld.ejs',{'datadisplay' : datafound, title:'All data recieved from user'} );//can use datadisplay
        }, (err) => next(err))
    .catch((err) => next(err));
    }, (err) => next(err))
    .catch((err) => next(err));
    console.log(req.body);
})

.put((req, res, next) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /phones/datausage');
})

.delete((req, res, next) => {
    res.statusCode = 403;
    res.end('Delete operation not  supported on /phones/datausage');
    
});



phonedatarouter.route('/delete/:id')

.get((req,res,next) => {
    console.log(req.params.id)
    console.log('Id: ')
    /*IDhold = req.query.id 
    IDhold = IDhold.trim()*/

    //console.log(req.query.id)
    phones.findByIdAndRemove({_id:req.params.id})
    .then((datataken) => {
        console.log('deleted')
        phones.find()
        .then((datafound) => {
            res.render('dataheld.ejs', {datadisplay: datafound, title:'data deletion'})
        }, (err) => next(err))
    })
    //res.render('dataheld.ejs', {title: 'data deleted'})
})
phonedatarouter.route('/update/:id')
/*.get((req,res,next) => {
    console.log(req.params.id)
    console.log('Id: ')
    phones.find(ObjectID(req.params.id)) 
            res.render('updateddata.ejs', { title: 'all usage'})
        })*/
.get((req, res, next) => {
    console.log(req.params.id)
    phones.findById({_id: req.params.id})
        .then((datafound) =>{
            console.log(datafound)
            res.render('updateddata.ejs', {'datadisplay': datafound, title:'All data'})
        })
    })

.post((req,res,next) => {
    phones.findByIdAndUpdate(req.params.id, req.body)
    .then((datafound) => {
        phones.find() 
        .then((datafound) => {
            res.render('dataheld.ejs', {'datadisplay' : datafound, title: 'All data recieved from user'});
        }, (err) => next(err))
        .catch((err) => next(err));
        }, (err) => next(err));
    })

  
//.get((req,res,next))
/*.post((req, res, next) => {
    phones.findByIdAndUpdate(req.body._id)
    .then((datataken) => {
        phones.find()
         .then((datafound) => {
                res.render('dataupdate.ejs',{'dataheld' : datafound, title:'All data recieved from user'} );//can use datadisplay
        }, (err) => next(err))
    .catch((err) => next(err));
    }, (err) => next(err))
    .catch((err) => next(err));
})*/

//.post()

phonedatarouter.route('/find')

.post((req, res, next) => {
    phones.find(req.body)
    .then((datataken) => {
        phones.find(req.body)
         .then((datafound) => {
                res.render('dataheld.ejs',{'datadisplay' : datafound, title:'All data recieved from user'} );//can use datadisplay
        }, (err) => next(err));
    })
})
//phonedatarouter.route('/update')


/*.get((req,res,next) => {
    console.log('The id is ',req.query)
    console.log(req.query.id)
    
    phones.findByIdAndRemove(req.query._id)
    .then((datataken) => {
        console.log('deleted')
        phones.find()
        .then((datafound) => {
            res.render('dataheld.ejs',{'datadisplay' : datafound, title: 'data deletion'})
        }, (err) => next(err))
    })
})*/

module.exports = phonedatarouter;