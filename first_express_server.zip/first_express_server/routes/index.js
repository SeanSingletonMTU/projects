var express = require('express');
var router = express.Router();
const phones = require('../models/phone')
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Phone Data Checker' });
});

router.get('/about', function(req, res, next) {
  res.render('about', { title: 'Phone Data Checker' });
});
router.get('/help', function(req, res, next) {
  res.render('help', { title: 'Phone Data Checker' });
});
module.exports = router;
