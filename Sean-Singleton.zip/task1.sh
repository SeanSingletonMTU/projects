# Check if the number of command line arguments is not equal to 2
if [ $# -ne 2 ]; then

  # If so, print a usage message and exit the script with an exit code of 1
  echo "Usage: $0 <directory> <pattern>"
  exit 1

fi

# Assign the first command line argument to the variable "directory"
directory="$1"

# Assign the second command line argument to the variable "pattern"
pattern="$2"

# Initialize an empty array called "file_array"
file_array=()

# Loop through all files in the directory
for file in "$directory"/*; do

  # Check if the current file is a regular file
  if [ -f "$file" ]; then

    # Print a message saying that the script is checking the file
    echo "Checking file: $file"

    # Use grep to search for the pattern in the file and count the number of matches
    pattern_count=$(grep -o -i "$pattern" "$file" | wc -l)

    # If the pattern appears in the file more than once, add the file name to the file_array
    if [ "$pattern_count" -gt 1 ]; then
      echo "File $file contains the pattern more than once."
      file_array+=("$(basename "$file")")
    fi

    # Print two blank lines to separate the output for each file
    echo ""
    echo ""

  fi

done

# If the file_array contains any elements
if [ ${#file_array[@]} -gt 0 ]; then

  # Create a subdirectory called "Report" in the original directory
  report_dir="$directory/Report"
  mkdir -p "$report_dir"

  # Create a file called "report.txt" in the subdirectory
  report_file="$report_dir/report.txt"

  # Print a message saying that the script is creating the report file
  echo "Creating report file: $report_file"

  # Write the names of the files in the file_array to the report file
  printf "%s\n" "${file_array[@]}" > "$report_file"

# If there were no files that contained the pattern at least twice
else

  # Print a message saying so
  echo "No files containing the pattern at least twice."

fi
