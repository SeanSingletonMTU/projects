#!/bin/bash

# Define functions for the menus

# Cork Query Menu function
function cork_query_menu {
  echo "Cork Query Menu"
  echo "================"
  echo "1. Display towns starting with 'Ba'"
  echo "2. Display towns starting with 'Mi'"
  echo "3. Return to Main Menu"
  read -P "Enter your choice: " cork_choice  # Read user's choice

  case $cork_choice in
    1)
      grep -i '^Ba' county-cork.txt;;  # Display towns starting with 'Ba'
    2)
      grep -i '^Mi' county-cork.txt;;  # Display towns starting with 'Mi'
    3)
      main_menu;;  # Return to main menu
    *)
      echo "Invalid choice. Please try again.";;  # Display error message
  esac

  cork_query_menu  # Call this function again for the next iteration
}

# Advert Query Menu function
function advert_query_menu {
  echo "The Advert Query Menu"
  echo "====================="
  read -p "What is your budget price (between 800-1300): " cost  # Prompt user for budget price

  if ((cost > 800 && cost <= 1300)); then  # If budget is within range
    grep "\$cost" advert.txt  # Display adverts with the specified budget price
  else
    echo "Cost is invalid/out of range. Please enter a new cost."  # Display error message
  fi

  advert_query_menu  # Call this function again for the next iteration
}

# Writing to File Menu function
function write_file_menu {
  read -p "What is the name of file: " filename  # Prompt user for file name
  if [ ! -f $filename ]; then  # Check if file already exists
    touch $filename  # Create file if it doesn't exist
  fi

  echo "Enter your text. Type 'stop' to finish."
  while true; do
    read input
    if [ "$input" == "stop" ]; then
      break  # Exit loop if user types 'stop'
    else
      echo $input >> $filename  # Append user input to the file
    fi
  done

  write_file_menu  # Call this function again for the next iteration
}

# Main loop for menu options
while true; do
  # Display menu options
  echo "##############"
  echo "1. Show Towns Starting with Ba/Mi"
  echo "2. Show Adverts"
  echo "3. Write to File"
  echo "0. Exit"

  # Ask user for input and execute corresponding function
  read -p "Enter your choice (1-4): " choice
  echo ""
  case $choice in
    1)
      cork_query_menu  # Call Cork Query Menu function
      ;;
    2)
      advert_query_menu  # Call Advert Query Menu function
      ;;
    3)
      write_file_menu  # Call Writing to File Menu function
      ;;
    0)
      echo "Exiting...."
      exit 0  # Exit the script
      ;;
    *)
      echo "Invalid choice. Please try again."  # Display error message
      ;;
  esac
done


