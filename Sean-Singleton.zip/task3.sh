#!/bin/bash

# This script automates the creation and deletion of user accounts
# It requires root user privileges to run
# Usage: ./user-accounts.sh <input-file>
# Example: ./user-accounts.sh users.txt

# Check if the script is being run as root user


if [ "$(whoami)" != "root" ]  && [ $# -ne 1 ] && [ -z "$1" ]; then
  echo 'This script needs a few requirements to run'
  echo 'The script must be run as sudo: sudo bash "Task 3.sh"'
  echo 'This script must have a parameter as a file'
  echo 'The file parameter must be a valid file path.'
  exit 1
fi


# a function to create user accounts
add_users() {
    username=$1
    # Check if the user already exists
    if id "$username" &>/dev/null; then
        echo "User $username already exists, skipping..."
        continue
    fi
    # Create the user with a home directory and add them to a group with the same name
    useradd -m "$username"
    echo "User $username created"
}

remove_users() {
    username=$1
    # Check if the user exists
    if id "$username" &>/dev/null; then
        userdel -r "$username"
        echo "User $username deleted"
    fi
}


while read user; do
  add_users "$user"
done < "$1"

    
cat /etc/passwd
ls /home

read -p "Do you want to delete the previously made users? [y = yes any other button = no]" response
case "$response" in
    [yY])
        # Read the input file again and delete the user accounts
        while read -r username; do
            remove_users "$username"
        done < "$1"
        cat /etc/passwd
        ;;
    *)
        echo "Exiting without deleting any accounts"
        ;;
esac
