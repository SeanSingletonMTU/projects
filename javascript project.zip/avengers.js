var play_button = document.querySelector("#avenger");
if (play_button) {
	play_button.addEventListener("click",play,false);
}
function myFunction() {
  var x = document.getElementById("frm1");
  var text = "";
  var i;
  for (i = 0; i < x.length ;i++) {
    text += x.elements[i].value;
  }
  document.getElementById("demo").innerHTML = text;
}
function opinion() {
	var x = document.getElementById("myRange").value;
	if (x==1) {
		document.getElementById("opinionFeedback").innerHTML="Awful!"
	}
	else if (x==2) {
		document.getElementById("opinionFeedback").innerHTML="Not great"
	}
	else if (x==3) {
		document.getElementById("opinionFeedback").innerHTML="Good"
	}
	else if (x==4) {
		document.getElementById("opinionFeedback").innerHTML="Great"
	}
	else if (x==5) {
		document.getElementById("opinionFeedback").innerHTML="Amazing"
	}
}

		   
function play() {
	var randInt = Math.floor(Math.random() * 4);
	var hulk = 0
	var ironMan = 1
	var thor = 2
	var hawk = 3
	let ironMan_element = document.querySelector("#ironMan");
	let hulk_element = document.querySelector("#hulk");
	let thor_element = document.querySelector("#thor");
	let hawk_element = document.querySelector("#hawk");
	if (randInt === hulk){
			hulk_element.style.display = "block"
			ironMan_element.style.display = "none"
			thor_element.style.display = "none"
			hawk_element.style.display = "none"
			


		};
	if (randInt === ironMan){
				ironMan_element.style.display = "block"
				hulk_element.style.display = "none"		
				thor_element.style.display = "none"
				hawk_element.style.display = "none"


			};
	if (randInt === thor){
				thor_element.style.display = "block"
				hulk_element.style.display = "none"
				ironMan_element.style.display = "none"
				hawk_element.style.display = "none"


			};
	if (randInt === hawk){
				hawk_element.style.display = "block"
				hulk_element.style.display = "none"
				ironMan_element.style.display = "none"
				thor_element.style.display = "none"


			};		
};