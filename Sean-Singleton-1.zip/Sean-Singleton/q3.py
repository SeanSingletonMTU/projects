# so we will ctreate a recursive function and it will be called coverage()
#and it wants us to allow a integer parameter so we will pass one and call it number into the parameter and 
#seperately we will ask the user to input an integer only by using a while loop and a try and except
#so that an integer only can be entered
#In the converge function is where we will do the maths so dependin g on the integer inputted
# if it is odd we will multiply the number by 3 and + 1 and if even divide it by 2 using if statements and we will
# create an if statement to say if our users entered integer does hit 1 then return it so it stops as it asks for it too stop once it hits 1 and it always hits 1 after a certain amount of ime

def converge(number): #here is the function i talked about with the input parameter passed in so we can do the checks
    if number == 1:
        return number # we do this so the other statements will run until it hits 1 and then we return number 1
        'number = number // 2'
    elif number % 2 == 0:  #here we use an elif for the number chosen so if it is divisible by 2 itll be equal to 0 and then we can divide the number by 2
        number = number // 2
        print(number)
        return converge(number)# we get the new number so it can go again until in the first if statement it hits 1 and finishes 
    else:
        number = 1 + number * 3 # use an else statement to find out itis an odd number and when it is we add 1 to the number and multiply iy by 3
        print(number)
        return converge(number) # same as the even elif part we get the new number and check it again hence the recursive function until we hit 1

while True:
    number = input("enter an integer only: ") # create the input for user to enter the number
    try:
        number = int(number)# makes it so that it has to be a number or else it will go to the except and print the error and go back to the input and go until it gets a number 
        break
    except ValueError:
         print("please enter numbers only!")#just a small note not 100% sure if ive been doing the while true right if im putting the input in the right position did it the same as my last question it works because it wouldnt when i put it in the try or else i was making a mistake

print(converge(number))# run the whole process 