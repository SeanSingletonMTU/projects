#The plan for this q for me is too create 2 seperate functions and them both accepting the same parameter which 
#will be a list that i create so the functions can use this list to check if they for function 1 contain a hashtag and no M
#and the second function will be to check for common characters so when we pass the list parameter into these functions it will 
#check for both of these, so in the first function we will create a variable with a list comprehension that will check for hashtag and no M
#then use a for loop for checking each item in the list and return the list 
#for the second function again we create a list for common characters and create a for loop to go through these characters which will be given by the user
#using another for loop within this to filter throught the list for each item and then an if statement if there is an item in the list having a counter increment it
#and if the count is equal to the length of the list append the character to the list
#fresh new for loop  to loop through each character again and 
# # then nusing a for loop in this to loop thru each item in the created user list then we will count the occurence of a character in a word/item in the list to check for multiple of the same letter


def hash_and_no_m(list):
    #in order for me to filter out the items that have a # or dont begin with an m i used a list comprehension
    hash_and_no_m_list = [item for item in list if '#' in item and not item.startswith('m')]
    #i used a for loop to go through each item to find out if they have a hash or dont begin with an m
    for item in hash_and_no_m_list:
        print(f"{item} contains hash mark and does not start with m") #then just use a print statement to prove it or identtify it
        
    return hash_and_no_m_list


def check_for_common_chars(list):
    #first i will create an empty list to store the common characters in
    common_chars = []
    #now i will use a for loop to iterate through each character of the list thats given by the user
    for char in list[0]:
        count = 0 #here we use a counter to keep track of this
        for item in list: #use another loop here to go through each item in the user created list
            if char in item:
                count += 1 #what happens here is that if a common character is found the counter increases so it would go from 0 to 1 and so on
        if count == len(list):
            common_chars.append(char) #and here we use 'len' so if the count is equal to the length of the input list then the characters in all the items and the last line we append 
            #we add the character to the list we made for the common characters

    #loop thru each common character
    for char in common_chars:
        for item in list: #and againn loop thru each item in user created list
            count = item.count(char) #counts the number of times of a character in an item
            print(f"{item} contains {count} {char}") #using a print f statement we print the item,count of the char
    
    return common_chars


list = ["boby#", "borya#n", "#mallibons#", "morbs", "mobking#", "bunst#or"]

print("Hash marks and no m check:")


hash_and_no_m(list)

print("\nCommon character check:")
check_for_common_chars(list)  
