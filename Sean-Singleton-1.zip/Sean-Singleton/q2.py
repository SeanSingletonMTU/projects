#my method for what i will do for this task is too first off create a function
#for eliminating the player where i will after ask the user for an input between
#3-6 of how many players they want eliminated and using a while loop and
#try and except so the user has to enter between 3-6 or else it will constantly
#run and then what i will do is create another while loop for when we call the
#function where it elimiantes the player until it reaches the amount of times the
#user input has entered between 3-6 and each time we will use a time.sleep() function
#so that it will wait 30 seconds before eliminating a player and then once all the
#players are eliminated or the number th user entered we will display the original
#members entered and the new list which is the remaining players who werent eliminated 
#i will also need to import random for randomly selecting which player to get eliminated and 
#time for the sleep function so after every player eliminated there will be a 30 second delay as i said above


import time
import random

#as i said above created the function here 
def eliminating_the_player(players):
    '''eliminated_players = []'
    for i in range(num_wanted_eliminated): '''#loop through all the players in the game to be eliminated
    eliminated_player = random.choice(players) #choose which player to be eliminated from the game
    'eliminated_players.append(eliminated_player)'
    players.remove(eliminated_player) #remove said player from the list
    print(f"{eliminated_player} has been eliminated from the game")
    return players, eliminated_player #return the updated list of players after removing said player


#now we must get the players for the game off the user by creating the input statement and create a loop until all 12 are added and append each name into a list each time:
players = []
while len(players) < 12:
    enter_name = input(f"please enter a player name for the game: ")
    players.append(enter_name)


#after we have this, now we must choose the aount of players we want to eliminate by using a while loop and input for the user to enter the number between 3 and 6 
# we will also use try and except too make sure that the user can only enter a number and it be between 3 and 6 
while True:
    num_wanted_eliminated = input("enter number of players you want eliminated between 3 and 6: ")
    try:
        num_wanted_eliminated = int(num_wanted_eliminated)
        if 3 <= num_wanted_eliminated <= 6:
            break
        else:
            print("please enter only between 3 and 6 thank you!")
    except ValueError:
         print("please enter numbers only between 3 and 6 thank you!")


'''#also add the 30 second timer on elimination with using a while loop so that as long as the number of players left is greater than the number of players we want to eliminate each round 
while len (players) > num_wanted_eliminated:
    players = eliminating_the_player(players, num_wanted_eliminated) #calling the elimination function for each round so a random player can be eliminated 
    time.sleep(30) # and have it so there is a 30 second delay for each elimination'''

#here we will create a list and using a loop we look for the number of players to be eliminated
#then we will call our function to eliminate such a player
#then append the player to the list we make and then the timer to delay the loop for every elimination for 30 seconds 
eliminated_players = []
for i in range(num_wanted_eliminated):
    players, eliminated_player = eliminating_the_player(players)
    eliminated_players.append(eliminated_player)
    #print(f"{eliminated_player} has been eliminated from the game")
    time.sleep(30)
print("Game over result:", players) #here we are just showing the remaining players
print("Original list:", players + eliminated_players) #and here just showing the original list of players all the players pre elimination by taking the players left and the eliminated players that were put into the list eliminated_players